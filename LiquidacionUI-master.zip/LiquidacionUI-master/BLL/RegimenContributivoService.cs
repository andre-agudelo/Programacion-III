﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using DAL;

namespace BLL
{
    public class RegimenContributivoService
    {
        private RegimenContributivoRepository regimenContributivoRepository;
        public RegimenContributivoService()
        {
            regimenContributivoRepository = new RegimenContributivoRepository();
        }
        public double LiquidarCuotaModeradora(RegimenContributivo regimenContributivo)
        {
            double cuotaModeradora = 0;
            if (regimenContributivo.SalarioDevengado < (regimenContributivo.SalarioMinimo * 2))
            {
                regimenContributivo.CuotaModeradora = regimenContributivo.ValorServicio * regimenContributivo.TarifaUno;
                cuotaModeradora = regimenContributivo.CuotaModeradora;
            }
            if (regimenContributivo.SalarioDevengado >= (regimenContributivo.SalarioMinimo * 2) && regimenContributivo.SalarioDevengado < (regimenContributivo.SalarioMinimo * 5))
            {
                regimenContributivo.CuotaModeradora = regimenContributivo.ValorServicio * regimenContributivo.TarifaDos;
                cuotaModeradora = regimenContributivo.CuotaModeradora;
            }
            if (regimenContributivo.SalarioDevengado > (regimenContributivo.SalarioMinimo * 5))
            {
                regimenContributivo.CuotaModeradora = regimenContributivo.ValorServicio * regimenContributivo.TarifaUno;
                cuotaModeradora = regimenContributivo.CuotaModeradora;
            }

            return cuotaModeradora;
        }
        public void Guardar(RegimenContributivo regimenContributivo)
        {
            regimenContributivoRepository.Guardar(regimenContributivo);
        }
        public List<RegimenContributivo> Leer()
        {
            return regimenContributivoRepository.Leer();
        }
        public string Eliminar(List<RegimenContributivo> lRegimenContributivo, string numeroLiquidacion)
        {
            bool resultado = regimenContributivoRepository.Eliminar(lRegimenContributivo, numeroLiquidacion);
            if (resultado == true)
            {
                return "El registro ha sido eliminado satisfactoriamente";
            }
            else
            {
                return "El registro no fue encontrado, no pudo ser eliminado";
            }
        }
        public void Modificar(string numeroLiquidacion, List<RegimenContributivo> lRegimenContributivo, RegimenContributivo regimenContributivoModificado)
        {
            regimenContributivoRepository.Modificar(numeroLiquidacion, lRegimenContributivo, regimenContributivoModificado);
        }
    }
}
