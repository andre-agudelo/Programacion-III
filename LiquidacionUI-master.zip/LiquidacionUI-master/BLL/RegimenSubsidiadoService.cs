﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using DAL;
namespace BLL
{
    public class RegimenSubsidiadoService
    {
        private RegimenSubsidiadoRepository regimenSubsidiadoRepository;
        public RegimenSubsidiadoService()
        {
            regimenSubsidiadoRepository = new RegimenSubsidiadoRepository();
        }
        public double LiquidarCuotaModeradora(RegimenSubsidiado regimenSubsidiado)
        {
            return regimenSubsidiado.CuotaModeradora = regimenSubsidiado.ValorServicio * regimenSubsidiado.TarifaUno;
        }
        public void Guardar(RegimenSubsidiado regimenSubsidiado)
        {
            regimenSubsidiadoRepository.Guardar(regimenSubsidiado);
        }
        public List<RegimenSubsidiado> Leer()
        {
            return regimenSubsidiadoRepository.Leer();
        }
        public string Eliminar(List<RegimenSubsidiado> lRegimenSubsidiado, string numeroLiquidacion)
        {
            bool resultado = regimenSubsidiadoRepository.Eliminar(lRegimenSubsidiado, numeroLiquidacion);
            if (resultado == true)
            {
                return "El registro ha sido eliminado satisfactoriamente";
            }
            else
            {
                return "El registro no fue encontrado, no pudo ser eliminado";
            }
        }
        public void Modificar(string numeroLiquidacion, List<RegimenSubsidiado> lRegimenSubsidiado, RegimenSubsidiado regimenSusidiadoModificado)
        {
            regimenSubsidiadoRepository.Modificar(numeroLiquidacion, lRegimenSubsidiado, regimenSusidiadoModificado);
        }
    }
    
}
