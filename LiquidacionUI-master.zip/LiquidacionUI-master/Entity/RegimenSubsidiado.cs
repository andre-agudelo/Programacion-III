﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class RegimenSubsidiado : LiquidacionCuotaModeradora
    {
        public float TarifaUno { get; set; }
        public double TopeUno { get; set; }
        public RegimenSubsidiado()
        {
            TarifaUno = 0.5f;
            TopeUno = 200000;
        }
    }
}
