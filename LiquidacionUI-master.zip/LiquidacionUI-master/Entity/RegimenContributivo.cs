﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class RegimenContributivo : LiquidacionCuotaModeradora
    {
        public double SalarioDevengado { get; set; }
        public float TarifaUno { get; set; }
        public float TarifaDos { get; set; }
        public float TarifaTres { get; set; }
        public double TopeUno { get; set; }
        public double TopeDos { get; set; }
        public double TopeTres { get; set; }
        public RegimenContributivo()
        {
            TarifaUno = 0.15f;
            TarifaDos = 0.20f;
            TarifaTres = 0.25f;
            TopeUno = 250000;
            TopeDos = 900000;
            TopeTres = 1500000;
        }

    }
}
