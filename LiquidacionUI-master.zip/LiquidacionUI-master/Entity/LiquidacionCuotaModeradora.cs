﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class LiquidacionCuotaModeradora
    {
        public string NumeroLiquidacion { get; set; }
        public string IdentificacionPaciente { get; set; }
        public string TipoAfiliacion { get; set; }
        public double SalarioMinimo { get; set; }
        public double ValorServicio { get; set; }
        public double CuotaModeradora { get; set; }

        public LiquidacionCuotaModeradora()
        {
            SalarioMinimo = 980657;
        }
    }
}
