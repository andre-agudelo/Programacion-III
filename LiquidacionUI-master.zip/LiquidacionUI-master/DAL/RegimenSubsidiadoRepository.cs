﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using System.IO;

namespace DAL
{
    public class RegimenSubsidiadoRepository
    {
        string ruta = "RegimenSubsidiado.txt";
        public void Guardar(RegimenSubsidiado regimenSubsidiado)
        {
            FileStream file = new FileStream(ruta, FileMode.Append);
            StreamWriter escritor = new StreamWriter(file);
            escritor.WriteLine($"{regimenSubsidiado.NumeroLiquidacion};{regimenSubsidiado.IdentificacionPaciente};{regimenSubsidiado.TipoAfiliacion};{regimenSubsidiado.ValorServicio};{regimenSubsidiado.CuotaModeradora}");
            escritor.Close();
            file.Close();
        }

        public List<RegimenSubsidiado> Leer()
        {
            string linea;
            List<RegimenSubsidiado> lRegimenSubsidiado = new List<RegimenSubsidiado>();

            TextReader lector;
            lector = new StreamReader("RegimenSubsidiado.txt");
            while ((linea = lector.ReadLine()) != null)
            {
                RegimenSubsidiado regimenSubsidiado = new RegimenSubsidiado();
                char delimitador = ';';
                String[] arrayRegimenSubsidiado = linea.Split(delimitador);
                regimenSubsidiado.NumeroLiquidacion = arrayRegimenSubsidiado[0];
                regimenSubsidiado.IdentificacionPaciente = arrayRegimenSubsidiado[1];
                regimenSubsidiado.TipoAfiliacion = arrayRegimenSubsidiado[2];
                regimenSubsidiado.ValorServicio = Convert.ToDouble(arrayRegimenSubsidiado[3]);
                regimenSubsidiado.CuotaModeradora = Convert.ToDouble(arrayRegimenSubsidiado[4]);

                lRegimenSubsidiado.Add(regimenSubsidiado);
            }

            lector.Close();
            return lRegimenSubsidiado;
        }
        public bool Eliminar(List<RegimenSubsidiado> lRegimenSubsidiado, string numeroLiquidacion)
        {
            bool eliminacion = false;
            FileStream file = new FileStream(ruta, FileMode.Create);
            StreamWriter escritor = new StreamWriter(file);
            foreach (RegimenSubsidiado regimenSubsidiado in lRegimenSubsidiado)
            {
                if (regimenSubsidiado.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    lRegimenSubsidiado.Remove(regimenSubsidiado);
                    break;
                }

            }

            foreach (RegimenSubsidiado regimenSubsidiado in lRegimenSubsidiado)
            {
                escritor.WriteLine($"{regimenSubsidiado.NumeroLiquidacion};{regimenSubsidiado.IdentificacionPaciente};{regimenSubsidiado.TipoAfiliacion};{regimenSubsidiado.ValorServicio};{regimenSubsidiado.CuotaModeradora}");
            }
            escritor.Close();
            file.Close();

            foreach (RegimenSubsidiado regimenSubsidiado in lRegimenSubsidiado)
            {
                if (regimenSubsidiado.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    eliminacion = true;
                }
                else
                {
                    eliminacion = false;
                }
            }
            return eliminacion;
        }
        public void Modificar(string numeroLiquidacion, List<RegimenSubsidiado> lRegimenSubsidiado, RegimenSubsidiado regimenSubsidiadoModificado)
        {
            FileStream file = new FileStream(ruta, FileMode.Create);
            StreamWriter escritor = new StreamWriter(file);
            foreach (RegimenSubsidiado regimenSubsidiado in lRegimenSubsidiado)
            {
                if (regimenSubsidiado.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    lRegimenSubsidiado.Remove(regimenSubsidiado);
                    break;
                }

            }

            foreach (RegimenSubsidiado regimenSubsidiado in lRegimenSubsidiado)
            {
                escritor.WriteLine($"{regimenSubsidiado.NumeroLiquidacion};{regimenSubsidiado.IdentificacionPaciente};{regimenSubsidiado.TipoAfiliacion};{regimenSubsidiado.ValorServicio};{regimenSubsidiado.CuotaModeradora}");
            }
            escritor.Close();
            file.Close();

            Guardar(regimenSubsidiadoModificado);
        }
    }
}
