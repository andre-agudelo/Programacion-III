﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using System.IO;

namespace DAL
{
    public class RegimenContributivoRepository
    {
        string ruta = "RegimenContributivo.txt";
        public void Guardar(RegimenContributivo regimenContributivo)
        {
            FileStream file = new FileStream(ruta, FileMode.Append);
            StreamWriter escritor = new StreamWriter(file);
            escritor.WriteLine($"{regimenContributivo.NumeroLiquidacion};{regimenContributivo.IdentificacionPaciente};{regimenContributivo.TipoAfiliacion};{regimenContributivo.ValorServicio};{regimenContributivo.SalarioDevengado};{regimenContributivo.CuotaModeradora}");
            escritor.Close();
            file.Close();
        }
        public List<RegimenContributivo> Leer()
        {
            string linea;
            List<RegimenContributivo> lRegimenContributivo = new List<RegimenContributivo>();

            TextReader lector;
            lector = new StreamReader("RegimenContributivo.txt");
            while ((linea = lector.ReadLine()) != null)
            {
                RegimenContributivo regimenContributivo = new RegimenContributivo();
                char delimitador = ';';
                String[] arrayRegimenContributivo = linea.Split(delimitador);
                regimenContributivo.NumeroLiquidacion = arrayRegimenContributivo[0];
                regimenContributivo.IdentificacionPaciente = arrayRegimenContributivo[1];
                regimenContributivo.TipoAfiliacion = arrayRegimenContributivo[2];
                regimenContributivo.ValorServicio = Convert.ToDouble(arrayRegimenContributivo[3]);
                regimenContributivo.SalarioDevengado = Convert.ToDouble(arrayRegimenContributivo[4]);
                regimenContributivo.CuotaModeradora = Convert.ToDouble(arrayRegimenContributivo[5]);

                lRegimenContributivo.Add(regimenContributivo);
            }

            lector.Close();
            return lRegimenContributivo;
        }
        public bool Eliminar(List<RegimenContributivo> lRegimenContributivo, string numeroLiquidacion)
        {
            bool eliminacion = false;
            FileStream file = new FileStream(ruta, FileMode.Create);
            StreamWriter escritor = new StreamWriter(file);
            foreach (RegimenContributivo regimenContributivo in lRegimenContributivo)
            {
                if (regimenContributivo.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    lRegimenContributivo.Remove(regimenContributivo);
                    break;
                }

            }

            foreach (RegimenContributivo regimenContributivo in lRegimenContributivo)
            {
                escritor.WriteLine($"{regimenContributivo.NumeroLiquidacion};{regimenContributivo.IdentificacionPaciente};{regimenContributivo.TipoAfiliacion};{regimenContributivo.ValorServicio};{regimenContributivo.SalarioDevengado};{regimenContributivo.CuotaModeradora}");
            }
            escritor.Close();
            file.Close();

            foreach (RegimenContributivo regimenContributivo in lRegimenContributivo)
            {
                if (regimenContributivo.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    eliminacion = true;
                }
                else
                {
                    eliminacion = false;
                }
            }
            return eliminacion;
        }
        public void Modificar(string numeroLiquidacion, List<RegimenContributivo> lRegimenContributivo, RegimenContributivo regimenContributivoModificado)
        {
            FileStream file = new FileStream(ruta, FileMode.Create);
            StreamWriter escritor = new StreamWriter(file);
            foreach (RegimenContributivo regimenContributivo in lRegimenContributivo)
            {
                if (regimenContributivo.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    lRegimenContributivo.Remove(regimenContributivo);
                    break;
                }

            }

            foreach (RegimenContributivo regimenContributivo in lRegimenContributivo)
            {
                escritor.WriteLine($"{regimenContributivo.NumeroLiquidacion};{regimenContributivo.IdentificacionPaciente};{regimenContributivo.TipoAfiliacion};{regimenContributivo.ValorServicio};{regimenContributivo.SalarioDevengado};{regimenContributivo.CuotaModeradora}");
            }
            escritor.Close();
            file.Close();

            Guardar(regimenContributivoModificado);
        }
    }
}
