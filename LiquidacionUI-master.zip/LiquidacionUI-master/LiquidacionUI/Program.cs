﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using BLL;

namespace LiquidacionUI
{
    public class Program
    {
        public static RegimenSubsidiadoService regimenSubsidiadoService = new RegimenSubsidiadoService();
        public static RegimenContributivoService regimenContributivoService = new RegimenContributivoService();
        public static List<RegimenSubsidiado> lRegimenSubsidiado = new List<RegimenSubsidiado>();
        public static List<RegimenContributivo> lRegimenContributivo = new List<RegimenContributivo>();
        static void Main(string[] args)
        {
            Menu();
        }
        public static void Menu()
        {
            int operacion;
            do
            {
                Console.Clear();
                Console.WriteLine(".: MENU :.");
                Console.WriteLine("1 .. REGISTRO");
                Console.WriteLine("2 .. CONSULTA");
                Console.WriteLine("3 .. MODIFICACIÓN");
                Console.WriteLine("4 .. ELIMINACIÓN");
                Console.WriteLine("5 .. SALIR");
                operacion = Convert.ToInt32(Console.ReadLine());

                switch (operacion)
                {
                    case 1: Registro();
                        break;
                    case 2: Leer();
                        break;
                    case 3: Modificar();
                        break;
                    case 4: Eliminar();
                        break;
                    case 5: Console.WriteLine("Adiós");
                        break;
                    default:Console.WriteLine("La opción que ha elegido no es valida, por favor intente nuevamente");
                        break;
                }
            } while (operacion != 5);
        }
        public static void Registro()
        {
            int afiliacionActual;

            Console.Clear();
            Console.WriteLine(".: REGISTRO :.\n");
            Console.WriteLine("Tipo de afiliación:\n1 .. SUBSIDIADA\n2 .. CONTRIBUTIVA");
            afiliacionActual = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (afiliacionActual)
            {
                case 1:
                    RegistrarRegimenSubsidiado();
                    break;
                case 2:
                    RegistrarRegimenContributivo();
                    break;
                default:
                    Console.WriteLine("La opción que ha elegido no es valida, por favor intente nuevamente");
                    break;
            }
        }

        private static void RegistrarRegimenSubsidiado()
        {
            double cuotaModeradora;

            RegimenSubsidiado regimenSubsidiado = new RegimenSubsidiado();
            Console.WriteLine(".: REGIMEN SUBSIDIADO :.\n");
            Console.WriteLine("Numero de liquidación: ");
            regimenSubsidiado.NumeroLiquidacion = Console.ReadLine();
            Console.WriteLine("Identificación del paciente: ");
            regimenSubsidiado.IdentificacionPaciente = Console.ReadLine();
            Console.WriteLine("Valor del Servicio: ");
            regimenSubsidiado.ValorServicio = Convert.ToDouble(Console.ReadLine());

            cuotaModeradora = regimenSubsidiadoService.LiquidarCuotaModeradora(regimenSubsidiado);
            
            if (cuotaModeradora > 200000)
            {
                Console.WriteLine($"La liquidación es de {cuotaModeradora}, pero por ser mayor al tope maximo, ahora sera {regimenSubsidiado.TopeUno}");
                regimenSubsidiado.CuotaModeradora = regimenSubsidiado.TopeUno;
            }
            else
            {
                Console.WriteLine($"La liquidación es de {cuotaModeradora}");
            }

            regimenSubsidiado.TipoAfiliacion = "SUBSIDIADA";

            regimenSubsidiadoService.Guardar(regimenSubsidiado);
            Console.ReadKey();
        }

        private static void RegistrarRegimenContributivo()
        {
            double cuotaModeradora;

            RegimenContributivo regimenContributivo = new RegimenContributivo();
            Console.WriteLine(".: REGIMEN CONTRIBUTIVO :.\n");
            Console.WriteLine("Numero de liquidación: ");
            regimenContributivo.NumeroLiquidacion = Console.ReadLine();
            Console.WriteLine("Identificación del paciente: ");
            regimenContributivo.IdentificacionPaciente = Console.ReadLine();
            Console.WriteLine("Valor del Servicio: ");
            regimenContributivo.ValorServicio = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Salario devengado: ");
            regimenContributivo.SalarioDevengado = Convert.ToDouble(Console.ReadLine());

            cuotaModeradora = regimenContributivoService.LiquidarCuotaModeradora(regimenContributivo);

            if (regimenContributivo.SalarioDevengado < (regimenContributivo.SalarioMinimo * 2))
            {
                if (cuotaModeradora > regimenContributivo.TopeUno)
                {
                    Console.WriteLine($"La liquidación es de {cuotaModeradora}, pero por ser mayor al tope maximo, ahora sera {regimenContributivo.TopeUno}");
                    regimenContributivo.CuotaModeradora = regimenContributivo.TopeUno;
                }
                else
                {
                    Console.WriteLine($"La liquidación es de {cuotaModeradora}");
                }
            }
            if (regimenContributivo.SalarioDevengado >= (regimenContributivo.SalarioMinimo * 2) && regimenContributivo.SalarioDevengado < (regimenContributivo.SalarioMinimo * 5))
            {
                if (cuotaModeradora > regimenContributivo.TopeDos)
                {
                    Console.WriteLine($"La liquidación es de {cuotaModeradora}, pero por ser mayor al tope maximo, ahora sera {regimenContributivo.TopeDos}");
                    regimenContributivo.CuotaModeradora = regimenContributivo.TopeDos;
                }
                else
                {
                    Console.WriteLine($"La liquidación es de {cuotaModeradora}");
                }
            }
            if (regimenContributivo.SalarioDevengado > (regimenContributivo.SalarioMinimo * 5))
            {
                if (cuotaModeradora > regimenContributivo.TopeTres)
                {
                    Console.WriteLine($"La liquidación es de {cuotaModeradora}, pero por ser mayor al tope maximo, ahora sera {regimenContributivo.TopeTres}");
                    regimenContributivo.CuotaModeradora = regimenContributivo.TopeTres;
                }
                else
                {
                    Console.WriteLine($"La liquidación es de {cuotaModeradora}");
                }
            }

            regimenContributivo.TipoAfiliacion = "CONTRIBUTIVA";

            regimenContributivoService.Guardar(regimenContributivo);
            Console.ReadKey();
        }
        public static void Leer()
        {
            Console.Clear();
            int afiliacionActual;
            Console.WriteLine(".: MOSTRAR :.\n");
            Console.WriteLine("Tipo de afiliación:\n1 .. SUBSIDIADA\n2 .. CONTRIBUTIVA");
            afiliacionActual = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (afiliacionActual)
            {
                case 1:
                    LeerRegimenSubsidiado();
                    break;
                case 2:LeerRegimenContributivo();
                    break;
                default:
                    Console.WriteLine("La opción que ha elegido no es valida, por favor intente nuevamente");
                    break;
            }
        }
        public static void LeerRegimenSubsidiado()
        {
            Console.WriteLine(".: REGIMEN SUBSIDIADO :.");
            int contador = 1;

            lRegimenSubsidiado = regimenSubsidiadoService.Leer();

            foreach (RegimenSubsidiado s in lRegimenSubsidiado)
            {
                Console.WriteLine($"-------------------- {contador} --------------------");

                Console.WriteLine($"Numero de liquidacion: {s.NumeroLiquidacion}");
                Console.WriteLine($"Identificación paciente: {s.IdentificacionPaciente}");
                Console.WriteLine($"Tipo de afiliación: {s.TipoAfiliacion}");
                Console.WriteLine($"Valor del servicio: {s.ValorServicio}");
                Console.WriteLine($"Cuota moderadora {s.CuotaModeradora}");
                

                contador++;
            }

            Console.ReadKey();
        }
        public static void LeerRegimenContributivo()
        {
            Console.WriteLine(".: REGIMEN CONTRIBUTIVO :.");
            int contador = 1;

            lRegimenContributivo = regimenContributivoService.Leer();

            foreach (RegimenContributivo s in lRegimenContributivo)
            {
                Console.WriteLine($"-------------------- {contador} --------------------");

                Console.WriteLine($"Numero de liquidacion: {s.NumeroLiquidacion}");
                Console.WriteLine($"Identificación paciente: {s.IdentificacionPaciente}");
                Console.WriteLine($"Tipo de afiliación: {s.TipoAfiliacion}");
                Console.WriteLine($"Valor del servicio: {s.ValorServicio}");
                Console.WriteLine($"Salario devengado {s.SalarioDevengado}");
                Console.WriteLine($"Cuota moderadora {s.CuotaModeradora}");


                contador++;
            }

            Console.ReadKey();
        }
        public static void Eliminar()
        {
            Console.Clear();
            int afiliacionActual;
            Console.WriteLine(".: ELIMINAR :.\n");
            Console.WriteLine("Tipo de afiliación:\n1 .. SUBSIDIADA\n2 .. CONTRIBUTIVA");
            afiliacionActual = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (afiliacionActual)
            {
                case 1:EliminarRegimenSubsidiado();
                    break;
                case 2:EliminarRegimenContributivo();
                    break;
                default:
                    Console.WriteLine("La opción que ha elegido no es valida, por favor intente nuevamente");
                    break;
            }
        }
        public static void EliminarRegimenSubsidiado()
        {
            string numeroLiquidacion;

            Console.WriteLine("Digite el numero de liquidación del registro que desea eliminar: ");
            numeroLiquidacion = Console.ReadLine();
            regimenSubsidiadoService.Eliminar(lRegimenSubsidiado, numeroLiquidacion);

            Console.ReadKey();
        }
        public static void EliminarRegimenContributivo()
        {
            string numeroLiquidacion;

            Console.WriteLine("Digite el numero de liquidación del registro que desea eliminar: ");
            numeroLiquidacion = Console.ReadLine();
            regimenContributivoService.Eliminar(lRegimenContributivo, numeroLiquidacion);

            Console.ReadKey();
        }
        public static void Modificar()
        {
            Console.Clear();
            int afiliacionActual;
            Console.WriteLine(".: MODIFICAR :.\n");
            Console.WriteLine("Tipo de afiliación:\n1 .. SUBSIDIADA\n2 .. CONTRIBUTIVA");
            afiliacionActual = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (afiliacionActual)
            {
                case 1:
                    ModificarRegimenSubsidiado();
                    break;
                case 2:
                    ModificarRegimenContributivo();
                    break;
                default:
                    Console.WriteLine("La opción que ha elegido no es valida, por favor intente nuevamente");
                    break;
            }
        }
        public static void ModificarRegimenSubsidiado()
        {
            string numeroLiquidacion;
            Console.WriteLine(".: REGIMEN SUBSIDIADO :.\n");
            Console.WriteLine("Digite el número de liquidación que desea modificar: ");
            numeroLiquidacion = Console.ReadLine();

            foreach (RegimenSubsidiado s in lRegimenSubsidiado)
            {
                if (s.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    RegimenSubsidiado regimenSubsidiadoModificado = new RegimenSubsidiado();

                    Console.WriteLine($"Numero de liquidacion: {s.NumeroLiquidacion}");
                    Console.WriteLine($"Identificación paciente: {s.IdentificacionPaciente}");
                    Console.WriteLine($"Tipo de afiliación: {s.TipoAfiliacion}");
                    Console.WriteLine($"Valor del servicio: {s.ValorServicio}");
                    Console.WriteLine($"Cuota moderadora {s.CuotaModeradora}");

                    regimenSubsidiadoModificado.NumeroLiquidacion = numeroLiquidacion;
                    Console.WriteLine($"Identificación paciente: ");
                    regimenSubsidiadoModificado.IdentificacionPaciente = Console.ReadLine();
                    Console.WriteLine($"Valor del servicio: ");
                    regimenSubsidiadoModificado.ValorServicio = Convert.ToDouble(Console.ReadLine());

                    regimenSubsidiadoModificado.TipoAfiliacion = "SUBSIDIADO";
                    regimenSubsidiadoService.LiquidarCuotaModeradora(regimenSubsidiadoModificado);

                    regimenSubsidiadoService.Modificar(numeroLiquidacion, lRegimenSubsidiado, regimenSubsidiadoModificado);

                }
            }
        }
        public static void ModificarRegimenContributivo()
        {
            string numeroLiquidacion;
            Console.WriteLine(".: REGIMEN CONTRIBUTIVO :.\n");
            Console.WriteLine("Digite el número de liquidación que desea modificar: ");
            numeroLiquidacion = Console.ReadLine();

            foreach (RegimenContributivo c in lRegimenContributivo)
            {
                if (c.NumeroLiquidacion.Equals(numeroLiquidacion))
                {
                    double cuotaModeradora;
                    RegimenContributivo regimenContributivoModificado = new RegimenContributivo();

                    Console.WriteLine($"Numero de liquidacion: {c.NumeroLiquidacion}");
                    Console.WriteLine($"Identificación paciente: {c.IdentificacionPaciente}");
                    Console.WriteLine($"Tipo de afiliación: {c.TipoAfiliacion}");
                    Console.WriteLine($"Valor del servicio: {c.ValorServicio}");
                    Console.WriteLine($"Salario devengado: {c.SalarioDevengado}");
                    Console.WriteLine($"Cuota moderadora {c.CuotaModeradora}");

                    regimenContributivoModificado.NumeroLiquidacion = numeroLiquidacion;
                    Console.WriteLine($"Identificación paciente: ");
                    regimenContributivoModificado.IdentificacionPaciente = Console.ReadLine();
                    Console.WriteLine($"Valor del servicio: ");
                    regimenContributivoModificado.ValorServicio = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine($"Salario devengado: ");
                    regimenContributivoModificado.SalarioDevengado = Convert.ToDouble(Console.ReadLine());

                    regimenContributivoModificado.TipoAfiliacion = "CONTRIBUTIVO";
                    cuotaModeradora = regimenContributivoService.LiquidarCuotaModeradora(regimenContributivoModificado);
                    
                    if (regimenContributivoModificado.SalarioDevengado < (regimenContributivoModificado.SalarioMinimo * 2))
                    {
                        if (cuotaModeradora > regimenContributivoModificado.TopeUno)
                        {
                            Console.WriteLine($"La liquidación es de {cuotaModeradora}, pero por ser mayor al tope maximo, ahora sera {regimenContributivoModificado.TopeUno}");
                            regimenContributivoModificado.CuotaModeradora = regimenContributivoModificado.TopeUno;
                        }
                        else
                        {
                            Console.WriteLine($"La liquidación es de {cuotaModeradora}");
                        }
                    }
                    if (regimenContributivoModificado.SalarioDevengado >= (regimenContributivoModificado.SalarioMinimo * 2) && regimenContributivoModificado.SalarioDevengado < (regimenContributivoModificado.SalarioMinimo * 5))
                    {
                        if (cuotaModeradora > regimenContributivoModificado.TopeDos)
                        {
                            Console.WriteLine($"La liquidación es de {cuotaModeradora}, pero por ser mayor al tope maximo, ahora sera {regimenContributivoModificado.TopeDos}");
                            regimenContributivoModificado.CuotaModeradora = regimenContributivoModificado.TopeDos;
                        }
                        else
                        {
                            Console.WriteLine($"La liquidación es de {cuotaModeradora}");
                        }
                    }
                    if (regimenContributivoModificado.SalarioDevengado > (regimenContributivoModificado.SalarioMinimo * 5))
                    {
                        if (cuotaModeradora > regimenContributivoModificado.TopeTres)
                        {
                            Console.WriteLine($"La liquidación es de {cuotaModeradora}, pero por ser mayor al tope maximo, ahora sera {regimenContributivoModificado.TopeTres}");
                            regimenContributivoModificado.CuotaModeradora = regimenContributivoModificado.TopeTres;
                        }
                        else
                        {
                            Console.WriteLine($"La liquidación es de {cuotaModeradora}");
                        }
                    }

                    regimenContributivoService.Modificar(numeroLiquidacion, lRegimenContributivo, regimenContributivoModificado);

                }
            }
        }
    }
}
